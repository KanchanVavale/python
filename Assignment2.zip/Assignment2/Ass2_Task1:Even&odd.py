#To check if the number is even or odd

num = int(input("Enter any number: "))

if num%2 == 0:
    print(f"{num} is an even number")
else:
    print(f"{num} is an odd number")


