#To define and call fatorial fucntion
def factorial(num):
    fact = 1 
    for i in range(1,num+1):
        fact = fact * i
    return fact

num = int(input("Enter a number: "))
result = factorial(num)
print(f"Factorial of {num} is: {result}")

